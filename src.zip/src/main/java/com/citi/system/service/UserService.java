package com.citi.system.service;

import com.citi.system.dto.User;

public interface UserService { 
	boolean verifyUser(User user);

}
