package com.citi.system.repository;

import com.citi.system.dto.User;

public interface UserRepository {

	public boolean verifyUser(User user);
	
}
