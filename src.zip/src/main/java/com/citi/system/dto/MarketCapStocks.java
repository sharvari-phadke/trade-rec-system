package com.citi.system.dto;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MarketCapStocks { 
	private int jsonArrayIndex;
	private String stockName;
	private BigDecimal currPrice;
	private BigDecimal twoWkOldClosingPrice;	
}
