package com.citi.system.dto;

public class StockRecommendation {

}
