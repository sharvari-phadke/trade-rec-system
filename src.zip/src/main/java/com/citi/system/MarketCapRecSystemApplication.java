package com.citi.system;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import com.citi.system.dto.StockDTO;
import com.citi.system.entities.CapWiseStockSymbols; 
import com.citi.system.service.StockRecService;

@SpringBootApplication
public class MarketCapRecSystemApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext apc= SpringApplication.run(MarketCapRecSystemApplication.class, args);
//		User u= new User("sharvari_p","sphadke1");
//		UserRepository ur= (UserRepository) apc.getBean("UserRepository");
//		ur.verifyUser(u);
			
	}

}
